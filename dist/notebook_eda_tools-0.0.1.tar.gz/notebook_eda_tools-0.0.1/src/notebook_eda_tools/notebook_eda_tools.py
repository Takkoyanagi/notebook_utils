""" Modules for useful tooling in a notebook."""

def add_one(number):
    return number + 1
